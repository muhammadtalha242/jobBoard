﻿'use strict';
var express = require('express');
var router = express.Router();
var User = require('../models/user.model.js');

/* GET users listing. */
router.get('/allnotifications', function (req, res) {
    res.render('allnotifications');
});



module.exports = router;
