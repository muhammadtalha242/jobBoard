'use strict';
var express = require('express');
var User = require('../models/user.model.js');
var router = express.Router();


/* GET users listing. */
router.get('/:id', function (req, res) {
    if (req.session.loggedIn == true) {

        User.findById(req.params.id, function (err, user) {

            if (err) { console.log(err) }
            else {
                res.render('profile', { user: user });
            }

        });

    }

    else {

       
        res.redirect('../login');
    }


});

router.post('/notiupdate', function (req, res) {
console.log(req.body.jobPreference);
    var minused = req.body.jobPreference;
    var usere = req.session.user;


    User.findOneAndUpdate({ _id: usere._id }, { $set: { "jobPreference": minused } }, { new: true }, function (err, post) {

        if (err) { console.log(err) }
        else {
            req.session.user = post;
            req.session.save();
         



        }

    });
  

});

router.post('/cvupdate', function (req, res) {
        console.log(req.body.education);
        var firstname = req.body.firstname;
        var lastname = req.body.lastname;
        var contactno = req.body.contactno;
        var education = req.body.education;
        var fieldofstudy = req.body.fieldofstudy;
        var school = req.body.school;
        var jobtitle = req.body.jobtitle;
        var jobcompany = req.body.jobcompany;
        var joblocation = req.body.joblocation;
        var jobdesc = req.body.jobdesc;
        var usere = req.session.user;
    
    
        User.findOneAndUpdate({ _id: usere._id }, { $set: { "firstname": firstname, "lastname": lastname, "contactno": contactno, "education": education, "fieldofstudy": fieldofstudy, "school": school, "jobtitle": jobtitle, "jobcompany":jobcompany, "joblocation": joblocation, "jobdesc":jobdesc } }, { new: true }, function (err, post) {
    
            if (err) { console.log(err) }
            else {
                req.session.user = post;
                req.session.save();
             
    
    
    
            }
    
        });
      
    
    });

module.exports = router;
