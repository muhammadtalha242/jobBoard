var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/jobBoard', {useNewUrlParser: true}); 


var db = module.exports = mongoose.connection;